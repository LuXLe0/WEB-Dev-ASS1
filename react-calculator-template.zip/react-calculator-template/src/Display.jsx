import React from 'react';

function Display({ value }) {
  return (
    <div className="display">
      {value}
    </div>
  );
}

export default Display;
