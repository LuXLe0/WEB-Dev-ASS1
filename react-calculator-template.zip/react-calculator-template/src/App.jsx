import React, { useState } from 'react';
import './App.css';
import Display from './Display'; // Adjust the path as necessary
import Keypad from './Keypad'; // Adjust the path as necessary

function App() {
  const [input, setInput] = useState('');

  function handleInput(value) {
    setInput(input + value);
  }

  function calculate() {
    try {
      const result = new Function('return ' + input)();
      setInput(String(result));
    } catch {
      setInput('Error');
    }
  }

  function clear() {
    setInput('');
  }

  return (
    <div className="App">
      <h1>Simple Calculator</h1>
      <Display value={input} />
      <Keypad onInput={handleInput} onCalculate={calculate} onClear={clear} />
    </div>
  );
}

export default App;
